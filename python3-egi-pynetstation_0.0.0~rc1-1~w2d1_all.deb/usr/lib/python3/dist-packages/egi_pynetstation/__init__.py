"""
    Python interface to interact with EGI Netstation

    NTP Synch capability is included

"""

__version__ = '0.0.0rc0'
