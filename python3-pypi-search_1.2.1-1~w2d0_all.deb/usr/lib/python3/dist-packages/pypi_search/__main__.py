from pypi_search.main import main


if __name__ == '__main__':
    exit(main())
