import importlib.metadata
__version__ = importlib.metadata.version("psychopy-eyelink-coregraphics")
_last_updated = '07/10/2024'

from .EyeLinkCoreGraphicsPsychoPy import EyeLinkCoreGraphicsPsychoPy
