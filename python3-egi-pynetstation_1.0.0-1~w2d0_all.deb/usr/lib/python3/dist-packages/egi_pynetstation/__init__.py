"""
    Python interface to interact with EGI Netstation

    NTP Synch capability is included

"""

__version__ = '1.0.0'
